//
//  ValuesOfPizza.swift
//  pizzaChooserAppWatchOS WatchKit Extension
//
//  Created by Alejandro Martinez Montero on 24/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import WatchKit

class ValuesOfPizza: NSObject {
    var sizePizza: String = "Pequeña"
    var typePizza: String = "Delgada"
    var cheesePizza: String = "Sin queso"
    var extrasPizza: [String] = ["", "", "", "", ""]
    
    
    init(sizeP: String, typeP: String, cheeseP: String, extraP: [String]) {
        sizePizza = sizeP
        typePizza = typeP
        cheesePizza = cheeseP
        extrasPizza = extraP
        
    }
    

}
