//
//  FinalResultInterfaceController.swift
//  pizzaChooserAppWatchOS WatchKit Extension
//
//  Created by Alejandro Martinez Montero on 24/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import WatchKit
import Foundation


class FinalResultInterfaceController: WKInterfaceController {

    @IBOutlet var titleResult: WKInterfaceLabel!
    @IBOutlet var sizePizzaElement: WKInterfaceLabel!
    @IBOutlet var typePizzaElement: WKInterfaceLabel!
    @IBOutlet var cheesePizzaElement: WKInterfaceLabel!
    @IBOutlet var extrasPizzaElement: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        
        let resultsOfPizza = context as! ValuesOfPizza
        sizePizzaElement.setText(resultsOfPizza.sizePizza)
        typePizzaElement.setText(resultsOfPizza.typePizza)
        cheesePizzaElement.setText(resultsOfPizza.cheesePizza)
        var extrasValues = resultsOfPizza.extrasPizza[0] + " " + resultsOfPizza.extrasPizza[1] + " " + resultsOfPizza.extrasPizza[2] + " " + resultsOfPizza.extrasPizza[3] + " " + resultsOfPizza.extrasPizza[4]
        
        extrasPizzaElement.setText(extrasValues)
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
