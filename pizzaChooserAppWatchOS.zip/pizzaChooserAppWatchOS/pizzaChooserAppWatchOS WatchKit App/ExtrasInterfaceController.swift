//
//  ExtrasInterfaceController.swift
//  pizzaChooserAppWatchOS WatchKit Extension
//
//  Created by Alejandro Martinez Montero on 24/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import WatchKit
import Foundation


class ExtrasInterfaceController: WKInterfaceController {

    @IBOutlet var hamSwitch: WKInterfaceSwitch!
    @IBOutlet var peperoniSwitch: WKInterfaceSwitch!
    @IBOutlet var anchoaSwitch: WKInterfaceSwitch!
    @IBOutlet var sardinasSwitch: WKInterfaceSwitch!
    @IBOutlet var pineappleSwitch: WKInterfaceSwitch!
    var sizePizzaElement: String = ""
    var typePizzaElement: String = ""
    var cheesePizzaElement: String = ""
    var extrasPizzaElement: [String] = ["","","","",""]
    var myBoolHam: Bool = false
    var myBoolPepe: Bool = false
    var myBoolAnchoa: Bool = false
    var myBoolSardina: Bool = false
    var myBoolPineapple: Bool = false
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let extraObject = context as! ValuesOfPizza
        sizePizzaElement = extraObject.sizePizza
        typePizzaElement = extraObject.typePizza
        cheesePizzaElement = extraObject.cheesePizza
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    @IBAction func hamActionSwitch(_ value: Bool) {
        myBoolHam = value
        
        if value {
            extrasPizzaElement[0] = "Jamon"
        }
        else {
            extrasPizzaElement[0] = ""
        }
    }
    
    @IBAction func peperoniActionSwitch(_ value: Bool) {
        myBoolPepe = value
        if value {
            extrasPizzaElement[1] = "Peperoni"
        }
        else {
            extrasPizzaElement[1] = ""
        }
    }
    
    @IBAction func anchoaActionSwitch(_ value: Bool) {
        myBoolAnchoa = value
        
        if value {
            extrasPizzaElement[2] = "Anchoas"
        }
        else {
            extrasPizzaElement[2] = ""
        }
    }
    
    
    @IBAction func sardinaActionSwitch(_ value: Bool) {
        myBoolSardina = value
        
        if value {
            extrasPizzaElement[3] = "Sardinas"
        }
        else {
            extrasPizzaElement[3] = ""
        }
    }
    
    
    @IBAction func pinhaActionSwitch(_ value: Bool) {
        myBoolPineapple = value
        
        if value {
            extrasPizzaElement[4] = "Piña"
        }
        else {
            extrasPizzaElement[4] = ""
        }
    }
    
    
    @IBAction func extrasButtonAction() {

        if myBoolHam || myBoolPepe || myBoolAnchoa || myBoolSardina || myBoolPineapple {
            
            let finalResultObject = ValuesOfPizza(sizeP: sizePizzaElement, typeP: typePizzaElement, cheeseP: cheesePizzaElement, extraP: extrasPizzaElement)
            pushController(withName: "ExtrasControllerObject", context: finalResultObject)
        }
        

        
        
        
        
        
    }
}
